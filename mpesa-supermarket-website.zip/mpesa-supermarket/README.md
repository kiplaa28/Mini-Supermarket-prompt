# M-Pesa Supermarket Cashier Website

Responsive cashier website for a mini supermarket using Lipa na M-Pesa STK Push.

## Included
- Mobile-friendly cashier dashboard
- Phone number and amount entry
- STK Push request endpoint
- Payment status polling
- Demo approve/decline flow
- Daily transaction table and totals
- SQLite transaction persistence
- Daraja OAuth, STK Push, STK Push Query and callback handling
- Duplicate callback / receipt protection and amount verification

## Run locally
Requires Node.js 18 or newer.

```bash
npm install
cp .env.example .env
npm start
```

Open `http://localhost:3000`. The default mode is `mock`; no Safaricom credentials are needed to test the demo.

In demo mode, send a prompt and use **Approve demo** or **Decline** to simulate the customer's response. This is not a real payment.

## Configure Daraja sandbox
1. Create or use a Daraja app in the Safaricom Developer Portal.
2. Use the sandbox credentials and test shortcode/passkey supplied by the portal.
3. Expose the app through a public HTTPS URL and set `CALLBACK_URL` to `https://YOUR-HOST/api/callback`.
4. Set the following in `.env`:

```env
MPESA_MODE=sandbox
MPESA_CONSUMER_KEY=your_sandbox_consumer_key
MPESA_CONSUMER_SECRET=your_sandbox_consumer_secret
MPESA_SHORTCODE=174379
MPESA_PASSKEY=your_sandbox_passkey
CALLBACK_URL=https://YOUR-HOST/api/callback
MPESA_TRANSACTION_TYPE=CustomerBuyGoodsOnline
```

Restart the server after changing environment variables.

## Production
Production requires a Daraja application approved for the business and a Till/Paybill linked by Safaricom. Use the production credentials, real shortcode, passkey, and a stable public HTTPS callback URL. Do not use sandbox credentials in production. Confirm the required Daraja product and transaction type with Safaricom for your Till.

## Important
- The demo approval controls are available only in mock mode.
- Real customer PIN entry happens only on the customer's phone through Safaricom's STK prompt. This website must never request or store an M-Pesa PIN.
- Never put `.env` credentials in public source control or share them in screenshots.
- Use HTTPS in deployment.
- SQLite is suitable for a single server instance. For multiple tills or multiple server instances, migrate to a managed database such as PostgreSQL and add staff authentication/roles before wider deployment.
- Back up `data/till.db` regularly.
- The current interface is a cashier dashboard, not a public customer website.
