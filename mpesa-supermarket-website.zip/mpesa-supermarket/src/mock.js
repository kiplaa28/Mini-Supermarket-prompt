const { config } = require("./config");
const timers = new Map();

function scheduleTimeout(checkoutRequestId, callback) {
  const timer = setTimeout(() => callback(checkoutRequestId, 1037, "STK push timed out"), config.mockTimeoutSeconds * 1000);
  timers.set(checkoutRequestId, timer);
}
function clearTimeoutFor(checkoutRequestId) {
  const timer = timers.get(checkoutRequestId);
  if (timer) clearTimeout(timer);
  timers.delete(checkoutRequestId);
}
function mockPrompt(orderId) {
  return {
    MerchantRequestID: `MOCK-MERCHANT-${orderId}`,
    CheckoutRequestID: `MOCK-${orderId}`,
    ResponseCode: "0",
    ResponseDescription: "Success. Request accepted for processing.",
    CustomerMessage: "Success. Request accepted for processing."
  };
}
module.exports = { scheduleTimeout, clearTimeoutFor, mockPrompt };
