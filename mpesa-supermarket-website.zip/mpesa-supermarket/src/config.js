const path = require("path");
require("dotenv").config();

const mode = (process.env.MPESA_MODE || "mock").toLowerCase();
const config = {
  port: Number(process.env.PORT || 3000),
  mode: ["mock", "sandbox", "production"].includes(mode) ? mode : "mock",
  transactionType: process.env.MPESA_TRANSACTION_TYPE || "CustomerBuyGoodsOnline",
  consumerKey: process.env.MPESA_CONSUMER_KEY || "",
  consumerSecret: process.env.MPESA_CONSUMER_SECRET || "",
  shortcode: process.env.MPESA_SHORTCODE || "",
  passkey: process.env.MPESA_PASSKEY || "",
  callbackUrl: process.env.CALLBACK_URL || "",
  mockTimeoutSeconds: Number(process.env.MOCK_TIMEOUT_SECONDS || 60),
  dbPath: path.resolve(process.env.DB_PATH || "./data/till.db")
};

function liveConfigErrors() {
  if (config.mode === "mock") return [];
  const errors = [];
  for (const [key, value] of Object.entries({
    MPESA_CONSUMER_KEY: config.consumerKey,
    MPESA_CONSUMER_SECRET: config.consumerSecret,
    MPESA_SHORTCODE: config.shortcode,
    MPESA_PASSKEY: config.passkey,
    CALLBACK_URL: config.callbackUrl
  })) if (!value) errors.push(`${key} is missing`);
  if (config.callbackUrl && (!config.callbackUrl.startsWith("https://") || /localhost|127\.0\.0\.1/i.test(config.callbackUrl))) {
    errors.push("CALLBACK_URL must be a public HTTPS URL (not localhost)");
  }
  if (config.mode === "production" && config.shortcode === "174379") {
    errors.push("Sandbox shortcode 174379 cannot be used in production");
  }
  return errors;
}

module.exports = { config, liveConfigErrors };
