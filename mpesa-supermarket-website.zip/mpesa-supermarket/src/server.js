const express = require("express");
const crypto = require("crypto");
const path = require("path");
const { config, liveConfigErrors } = require("./config");
const { run, get, all, initDb } = require("./db");
const { stkPush, queryStk } = require("./daraja");
const { scheduleTimeout, clearTimeoutFor, mockPrompt } = require("./mock");

const app = express();
app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

const now = () => new Date().toISOString();
const makeId = () => `HF${Date.now().toString(36).toUpperCase()}${crypto.randomBytes(3).toString("hex").toUpperCase()}`;
function normalizePhone(value) {
  let phone = String(value || "").replace(/[^\d+]/g, "").replace(/^\+/, "");
  if (phone.startsWith("0")) phone = `254${phone.slice(1)}`;
  if (phone.startsWith("7") || phone.startsWith("1")) phone = `254${phone}`;
  if (!/^254[17]\d{8}$/.test(phone)) throw new Error("Enter a valid Kenyan mobile number, e.g. 0712345678");
  return phone;
}
function publicOrder(row) {
  return {
    id: row.id, phone: row.phone, amount: row.amount, status: row.status,
    receipt: row.receipt, resultDescription: row.result_description,
    createdAt: row.created_at, completedAt: row.completed_at
  };
}
async function updateOrder(checkoutId, resultCode, description, metadata = {}) {
  const row = await get("SELECT * FROM orders WHERE checkout_request_id = ?", [checkoutId]);
  if (!row || row.credited) return { credited: false };
  const code = Number(resultCode);
  if (code !== 0) {
    const status = [1032].includes(code) ? "cancelled" : [1036, 1037].includes(code) ? "timeout" : "failed";
    await run("UPDATE orders SET status=?, result_code=?, result_description=?, completed_at=? WHERE id=? AND credited=0",
      [status, String(code), description || status, now(), row.id]);
    return { credited: false, status };
  }
  const paidAmount = Number(metadata.Amount);
  const receipt = String(metadata.MpesaReceiptNumber || "");
  if (!receipt || paidAmount !== row.amount) {
    await run("UPDATE orders SET status='failed', result_code='AMOUNT_OR_RECEIPT_MISMATCH', result_description=?, completed_at=? WHERE id=?",
      ["Payment confirmation did not match the expected amount or receipt was missing.", now(), row.id]);
    return { credited: false, status: "failed" };
  }
  try {
    await run("UPDATE orders SET status='paid', receipt=?, result_code='0', result_description='Payment confirmed', credited=1, completed_at=? WHERE id=? AND credited=0",
      [receipt, now(), row.id]);
    return { credited: true, status: "paid", receipt };
  } catch (e) {
    // A duplicate receipt is not credited again.
    return { credited: false, status: "duplicate" };
  }
}
async function handleMockResult(checkoutId, code, description, metadata = {}) {
  clearTimeoutFor(checkoutId);
  return updateOrder(checkoutId, code, description, metadata);
}

app.get("/api/health", (_req, res) => {
  const errors = liveConfigErrors();
  res.json({ mode: config.mode, ready: errors.length === 0, errors, shortcode: config.mode === "mock" ? null : config.shortcode });
});

app.post("/api/stkpush", async (req, res) => {
  try {
    const amount = Number(req.body.amount);
    const phone = normalizePhone(req.body.phone);
    if (!Number.isInteger(amount) || amount < 1 || amount > 250000) {
      return res.status(400).json({ error: "Enter an amount in whole Kenya shillings, from 1 to 250,000." });
    }
    const errors = liveConfigErrors();
    if (errors.length) return res.status(503).json({ error: "M-Pesa is not configured yet.", details: errors });
    const id = makeId();
    await run("INSERT INTO orders (id, phone, amount, status, created_at) VALUES (?, ?, ?, 'pending', ?)",
      [id, phone, amount, now()]);
    let result;
    if (config.mode === "mock") {
      result = mockPrompt(id);
    } else {
      result = await stkPush({ amount, phone, orderId: id });
      if (String(result.ResponseCode) !== "0") {
        await run("UPDATE orders SET status='failed', result_description=? WHERE id=?",
          [result.ResponseDescription || "Safaricom rejected the request", id]);
        return res.status(400).json({ error: result.ResponseDescription || "STK Push could not be started." });
      }
    }
    await run("UPDATE orders SET checkout_request_id=?, merchant_request_id=? WHERE id=?",
      [result.CheckoutRequestID, result.MerchantRequestID, id]);
    if (config.mode === "mock") scheduleTimeout(result.CheckoutRequestID, (checkoutId, code, desc) => handleMockResult(checkoutId, code, desc));
    res.json({ orderId: id, checkoutRequestId: result.CheckoutRequestID, message: result.CustomerMessage || "Prompt sent. Ask the customer to check their phone." });
  } catch (e) {
    res.status(400).json({ error: e.response?.data?.errorMessage || e.message || "Could not start payment." });
  }
});

app.post("/api/callback", async (req, res) => {
  try {
    const callback = req.body?.Body?.stkCallback;
    if (!callback) return res.status(400).json({ ResultCode: 1, ResultDesc: "Invalid callback" });
    const metadata = {};
    for (const item of callback.CallbackMetadata?.Item || []) metadata[item.Name] = item.Value;
    await updateOrder(callback.CheckoutRequestID, callback.ResultCode, callback.ResultDesc, metadata);
    res.json({ ResultCode: 0, ResultDesc: "Accepted" });
  } catch (e) {
    console.error("Callback error:", e.message);
    res.status(500).json({ ResultCode: 1, ResultDesc: "Callback processing error" });
  }
});

app.get("/api/status/:id", async (req, res) => {
  const row = await get("SELECT * FROM orders WHERE id=?", [req.params.id]);
  if (!row) return res.status(404).json({ error: "Transaction not found." });
  res.json(publicOrder(row));
});

app.post("/api/stkpushquery", async (req, res) => {
  try {
    const row = await get("SELECT * FROM orders WHERE id=?", [req.body.orderId]);
    if (!row) return res.status(404).json({ error: "Transaction not found." });
    if (config.mode === "mock") return res.json({ message: "Demo payments are confirmed using the demo approve/decline controls." });
    if (!row.checkout_request_id) return res.status(409).json({ error: "No checkout request is available for this transaction." });
    const result = await queryStk({ checkoutRequestId: row.checkout_request_id });
    res.json(result);
  } catch (e) {
    res.status(502).json({ error: e.response?.data?.errorMessage || e.message });
  }
});

app.get("/api/transactions/today", async (_req, res) => {
  const today = new Date().toLocaleDateString("en-CA", { timeZone: "Africa/Nairobi" });
  const rows = await all("SELECT * FROM orders WHERE date(created_at, 'localtime') = date('now','localtime') ORDER BY created_at DESC LIMIT 200");
  const totals = await get("SELECT COUNT(*) AS count, COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) AS collected, SUM(CASE WHEN status='paid' THEN 1 ELSE 0 END) AS paidCount FROM orders WHERE date(created_at, 'localtime') = date('now','localtime')");
  res.json({ date: today, totals, transactions: rows.map(publicOrder) });
});

app.post("/api/mock/:checkoutRequestId/approve", async (req, res) => {
  if (config.mode !== "mock") return res.status(404).json({ error: "Not available outside demo mode." });
  const receipt = `MOCK${crypto.randomBytes(5).toString("hex").toUpperCase()}`;
  const result = await handleMockResult(req.params.checkoutRequestId, 0, "Demo payment approved", { Amount: Number(req.body.amount), MpesaReceiptNumber: receipt });
  res.json(result);
});
app.post("/api/mock/:checkoutRequestId/decline", async (req, res) => {
  if (config.mode !== "mock") return res.status(404).json({ error: "Not available outside demo mode." });
  res.json(await handleMockResult(req.params.checkoutRequestId, 1032, "Demo customer declined the prompt"));
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "..", "public", "index.html")));

initDb().then(() => {
  const errors = liveConfigErrors();
  console.log(`M-Pesa supermarket app running on port ${config.port} (${config.mode} mode)`);
  if (errors.length) console.warn("Configuration warnings:", errors.join("; "));
  app.listen(config.port, "0.0.0.0");
}).catch(err => { console.error("Database initialization failed:", err); process.exit(1); });
