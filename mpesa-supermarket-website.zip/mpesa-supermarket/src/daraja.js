const axios = require("axios");
const { config } = require("./config");

const base = config.mode === "production"
  ? "https://api.safaricom.co.ke"
  : "https://sandbox.safaricom.co.ke";

function timestamp() {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Africa/Nairobi", year: "numeric", month: "2-digit",
    day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit",
    hourCycle: "h23"
  }).formatToParts(new Date());
  const p = Object.fromEntries(parts.map(x => [x.type, x.value]));
  return `${p.year}${p.month}${p.day}${p.hour}${p.minute}${p.second}`;
}
async function accessToken() {
  const auth = Buffer.from(`${config.consumerKey}:${config.consumerSecret}`).toString("base64");
  const response = await axios.get(`${base}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` }, timeout: 20000
  });
  return response.data.access_token;
}
async function stkPush({ amount, phone, orderId }) {
  const token = await accessToken();
  const time = timestamp();
  const password = Buffer.from(`${config.shortcode}${config.passkey}${time}`).toString("base64");
  const payload = {
    BusinessShortCode: config.shortcode,
    Password: password,
    Timestamp: time,
    TransactionType: config.transactionType,
    Amount: amount,
    PartyA: phone,
    PartyB: config.shortcode,
    PhoneNumber: phone,
    CallBackURL: config.callbackUrl,
    AccountReference: orderId.slice(0, 12),
    TransactionDesc: "Supermarket payment"
  };
  const response = await axios.post(`${base}/mpesa/stkpush/v1/processrequest`, payload, {
    headers: { Authorization: `Bearer ${token}` }, timeout: 25000
  });
  return response.data;
}
async function queryStk({ checkoutRequestId }) {
  const token = await accessToken();
  const time = timestamp();
  const password = Buffer.from(`${config.shortcode}${config.passkey}${time}`).toString("base64");
  const response = await axios.post(`${base}/mpesa/stkpushquery/v1/query`, {
    BusinessShortCode: config.shortcode, Password: password, Timestamp: time,
    CheckoutRequestID: checkoutRequestId
  }, { headers: { Authorization: `Bearer ${token}` }, timeout: 20000 });
  return response.data;
}
module.exports = { stkPush, queryStk };
