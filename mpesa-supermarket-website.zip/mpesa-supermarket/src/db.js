const fs = require("fs");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const { config } = require("./config");

fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });
const db = new sqlite3.Database(config.dbPath);

function run(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function (err) {
    if (err) reject(err); else resolve({ lastID: this.lastID, changes: this.changes });
  }));
}
function get(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
}
function all(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows)));
}
async function initDb() {
  await run(`CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY, phone TEXT NOT NULL, amount INTEGER NOT NULL,
    status TEXT NOT NULL, checkout_request_id TEXT, merchant_request_id TEXT,
    receipt TEXT UNIQUE, result_code TEXT, result_description TEXT,
    credited INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
    completed_at TEXT
  )`);
  await run("CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at)");
}
module.exports = { db, run, get, all, initDb };
